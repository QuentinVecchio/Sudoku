#ifndef CREDIT_H
#define CREDIT_H
/*********************************************************************************************************************************************
*       Partie graphique Credit Header                                                                                                       *
*       Prototypes                                                                                                                           *
*       Fait par Quentin Vecchio                                                                                                             *
*       25 mai 2013                                                                                                                          *
*********************************************************************************************************************************************/
void  afficheCredit(GtkWidget *widget, gpointer data);
#endif
